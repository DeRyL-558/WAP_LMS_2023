Przykładowe przedmioty dla poszczególnych wydziałów:

IT Department
-Algorithms
-Numerical Methods
-Graphics and Visualization
-Engineering Tools
-Discrete Mathematics

Faculty of Managment
-Basics of Logistics
-Occupational Health and Safety
-Asset Protection
-Serving Clients and Contractors

Faculty of Humanities
-Fundamentals of Law
-Social Psychology
-The Science of Communication
-Information Control
