package com.uep.moodleproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MoodleProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(MoodleProjectApplication.class, args);
	}

}
